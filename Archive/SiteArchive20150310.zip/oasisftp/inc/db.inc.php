<?php
	require ("mysql_func.inc.php");

	class DB extends DB_MySql {
	  var $varHost     = "mysql.bucks.net";
	  var $varDatabase = "oasisprinting";
	  var $varUser     = "oasisprinting";
	  var $varPswd     = "ooGhai0l";
  } 

?>