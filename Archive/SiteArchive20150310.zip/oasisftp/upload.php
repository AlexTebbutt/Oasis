<?php
  include "inc/htmlfunc.inc.php";
  include "inc/db.inc.php";
  include "inc/adminfunc.inc.php";
  
  session_start();
//Check to see if the user is an admin, if not boot them back to the login page
  if (UserLoggedIn() || AdminLogedIn) {
  
    //Get Session variables
  
  
    //Get POST variables

    if (isset($_FILES['filename'])) {
      $varSourceFile = $_FILES['filename']['name'];
      $varDestinationFile = $_FILES['filename']['name'];
    } else {
      $varSourceFile = NULL;
      $varDestinationFile = NULL;   
    }
  
    
    DispHeader();

$ftp_server = "www.oasisprinting.com";
$ftp_user = "oasisprintingftp";
$ftp_pass = "49k1qqg7v1";

// set up a connection or die
$conn_id = ftp_connect($ftp_server) or die("Couldn't connect to $ftp_server"); 

// try to login
if (@ftp_login($conn_id, $ftp_user, $ftp_pass)) {
echo "Connected as $ftp_user@$ftp_server\n";
} else {
echo "Couldn't connect as $ftp_user\n";
}

ini_set('post_max_size','16M');
ini_set('upload_max_filesize','16M');

ftp_pasv($conn_id, true);
$remote_file = $_FILES['filename']['name'];;
//I used these for debugging
echo $_FILES['filename']['name'];
echo "<br />";
echo $_FILES['filename']['type'];
echo "<br />";
echo $_FILES['filename']['size'];
echo "<br />";
echo $_FILES['filename']['tmp_name'];
echo "<br />";
echo $_FILES['filename']['error'];
echo "<br />";

//v important this one as you have to use the tmp_file created for the actual upload
$file = $_FILES['filename']['tmp_name'];
if (ftp_put($conn_id, $remote_file, $file, FTP_BINARY)) {
echo "successfully uploaded $file\n";
} else {
echo "There was a problem while uploading $file\n";
}

// close the connection
ftp_close($conn_id);



?> 


    <form enctype="multipart/form-data" id="fileupload" name="fileupload" method="post" action="upload.php">
      <label>Choose a file to upload: </label><input name="filename" type="file" /><input type="submit" value="Upload File" />
    </form>
<?php  	
    DispFooter();
  
  }

?>