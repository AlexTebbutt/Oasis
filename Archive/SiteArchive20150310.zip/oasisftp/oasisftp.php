<?php
  include "inc/htmlfunc.inc.php";
  include "inc/db.inc.php";
  include "inc/adminfunc.inc.php";
  
  session_start();
  //Get Session variables
  if (!isset($_SESSION["Loggedin"])) $_SESSION["Loggedin"] = FALSE;
  
  //Get POST variables
  if (isset($_POST["Username"])) {
		$varUsername = $_POST["Username"];
	} else {
		$varUsername = NULL;
	}

	if (isset($_POST["Password"])) {
		$varPassword = $_POST["Password"];
	} else {
		$varPassword = NULL;
	}
  
  DispHeader();
	
	if (($_SESSION["Loggedin"] == FALSE) && (VerifyUser($varUsername, $varPassword) == FALSE)) {
    DispLogin($varUsername);    
	} else {
    if ($_SESSION["Administrator"] == TRUE) {
      echo "<meta http-equiv=\"Refresh\" content=\"0;url=adminmain.php\">";
    } else {
      echo "<meta http-equiv=\"Refresh\" content=\"0;url=usermain.php\">";
    }	 
	}
	
  DispFooter();

?>