<?php
  include "includes/htmlfunc.inc.php";
  include "includes/db.inc.php";
  include "includes/adminfunc.inc.php";
  
  session_start();
//Check to see if the user is an admin, if not boot them back to the login page
  if (AdminLoggedIn()) {
  
    //Get Session variables
  
  
    //Get POST variables
  
  
    
    DispHeader();
  	
    DispAdminOpt();
  	
    DispFooter();
  
  }

?>