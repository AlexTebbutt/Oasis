<?php
  include "inc/htmlfunc.inc.php";
  include "inc/db.inc.php";
  include "inc/adminfunc.inc.php";

  session_start();
  AdminLoggedIn();

  //Get POST variable
  if (isset($_POST["UserID"]) && empty($_POST["Clear"])) {
    $varUserID = $_POST["UserID"];
  } else {
    $varUserID = NULL;
  }
  
  if (isset($_POST["Username"]) && empty($_POST["Clear"])) {
    $varUsername = $_POST["Username"];
  } else {
    $varUsername = NULL;
  }

  if (isset($_POST["Fullname"]) && empty($_POST["Clear"])) {
    $varFullname = $_POST["Fullname"];
  } else {
    $varFullname = NULL;
  }

  if (isset($_POST["EmailAddress"]) && empty($_POST["Clear"])) {
    $varEmail = $_POST["EmailAddress"];
  } else {
    $varEmail = NULL;
  }

  if (isset($_POST["Enabled"]) && empty($_POST["Clear"])) {
    $varEnabled = 1;
  } else {
    $varEnabled = 0;
  }

  if (isset($_POST["Administrator"]) && empty($_POST["Clear"])) {
    $varAdministrator = 1;
  } else {
    $varAdministrator = 0;
  }
  
  $varLastLogin = NULL;

  if (isset($_POST["Delete"])) {
    $DB = new DB;
    $varSQL = "delete from USER where USERID = '".$_POST["UserID"]."'";   
        
    if ($DB->query($varSQL)) {
      echo "<p>User deleted</p>";
    } else {
      echo "<p class=\"error\">Query: $varSQL failed to execute</p>";  
    }
  }
  
  if (isset($_POST["Create"]) && isset($_POST["Username"]) && !empty($_POST["Password"]) && !empty($_POST["VerifyPassword"]) && ($_POST["VerifyPassword"] == $_POST["Password"])) {
  //Create user with supplied details
    $DB = new DB;
    $varSQL = "insert into USER (USERNAME, PASSWORD, FULLNAME, EMAIL, ADMINISTRATOR, ENABLED) ";
    $varSQL .="values ('$varUsername', '".$_POST["Password"]."', '$varFullname', '$varEmail', '$varAdministrator', '$varEnabled')";
        
    if ($DB->query($varSQL)) {
      echo "<p>User created</p>";
      $varPlayerID = $DB->getid();
    } else {
      echo "<p class=\"error\">Query: $varSQL failed to execute</p>";  
    }
  }

  if (isset($_POST["Update"]) && isset($_POST["Username"]) && !empty($_POST["Password"]) && !empty($_POST["VerifyPassword"]) && ($_POST["VerifyPassword"] == $_POST["Password"])) {
  // Update user details based on the user ID
    $DB = new DB;
    $varSQL = "update USER set Username = '$varUsername', FULLNAME = '$varFullname', EMAIL = '$varEmail', ";
    $varSQL .= "ENABLED = '$varEnabled', ADMINISTRATOR = '$varAdministrator', PASSWORD = '".$_POST["Password"]."' ";
    $varSQL .= "where PLAYER_ID ='$varPlayerID'";
    echo $varSQL;
    if ($DB->query($varSQL)) {
      echo "<p>User updated</p>";
    } else {
      echo "<p class=\"error\">Query: $varSQL failed to execute</p>";  
    }
  }

  if (isset($_POST["Retrieve"]) && (isset($_POST["Username"]))) {
  // Retrieve user details based on the user ID
    $DB = new DB;
    $varSQL = "select USERID, USERNAME, FULLNAME, EMAIL, LASTLOGIN, ADMINISTRATOR, ENABLED ";
    $varSQL .= "from USER where Username ='$varUsername'";
        
    if (!list($varUserID, $varUsername, $varFullname, $varEmail, $varLastLogin, $varAdministrator, $varEnabled) = $DB->frowquery($varSQL)) {
      echo "<p>No user with that Username</p>";  
    }
  }
 
  DispHeader();
  DispUserOpt();

?>    
<div id="UserAdmin">
  <h1>Edit User</h1>
  <form name="userprefs" method="post" action="manageusers.php">
    <p><label>User ID:</label><?php echo $varUserID; ?><input type="hidden" name="UserID" value="<?php echo $varUserID; ?>"></p>
    <p><label>Last Login:</label><?php echo $varLastLogin; ?> <?php echo date("d.m.Y"); ?></p>
  	<p><label>User Name:</label><input type="text" name="Username" id="Username" size="15" maxlength="30" value="<?php echo $varUsername; ?>"></p>
  	<p><label for="Fullname">Display Name:</label><input type="text" name="Fullname" id="Fullname" size="15" maxlength="30" value="<?php echo $varFullname; ?>">
  	<p><label for="Email">Email address:</label><input type="text" name="EmailAddress" id="EmailAddress" size="15" maxlength="30" value="<?php echo $varEmail; ?>">
  	<p><label for="Enabled">Enabled:</label><input type="checkbox" name="Enabled" <?php if ($varEnabled) echo "CHECKED"; ?>>
  	<p><label for="Administrator">Administrator:</label><input type="checkbox" name="Administrator" <?php if ($varAdministrator) echo "CHECKED"; ?>>
  	<p><label for="Password">Password:</label><input type="Password" name="Password" size="15" maxlength="30"></p>
  	<p><label for="VerifyPassword">Verify Password:</label><input type="VerifyPassword" name="VerifyPassword" size="15" maxlength="30"></p>
  	<p><input type="submit" name="Create" value="Create"><input type="submit" name="Update" value="Update"><input type="submit" name="Retrieve" value="Retrieve"><input type="submit" name="Delete" value="Delete"><input type="submit" name="Clear" value="Clear"></p>
  </form>
</div>
<?php    
  DispFooter();
?>