<?php
  include "inc/htmlfunc.inc.php";
  include "inc/db.inc.php";
  include "inc/adminfunc.inc.php";
  
  session_start();
//Check to see if the user is an admin, if not boot them back to the login page
  if (UserLoggedIn()) {
  
    //Get Session variables
  
  
    //Get POST variables
  
  
    
    DispHeader();
  	
    DispUserOpt();
  	
    DispFooter();
  
  }

?>