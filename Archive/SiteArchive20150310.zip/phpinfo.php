<?php
ini_set('post_max_size','16M');
ini_set('upload_max_filesize','16M');
  phpinfo();
?>